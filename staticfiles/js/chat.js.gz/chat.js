/* jshint esversion: 11 */
/* global roomId, currentUser,
handleCallAccepted, handleWebRTCOffer,
handleWebRTCAnswer, handleIceCandidate */


const protocol =
    window.location.protocol === "https:" ? "wss://" : "ws://";

window.chatSocket = new WebSocket(
    protocol + window.location.host + "/ws/chat/" + roomId + "/"
);

window.chatSocket.onopen = function() {

    if (sessionStorage.getItem("acceptIncomingCall") === "true") {

        sessionStorage.removeItem("acceptIncomingCall");

        document.getElementById("call-panel")
            .classList.remove("hidden");

        document.getElementById("call-status").innerText =
            "Connecting...";

        window.chatSocket.send(JSON.stringify({
            type: "call_accept"
        }));
    }
};


window.chatSocket.onmessage = function(e) {
    const data = JSON.parse(e.data);

    if (data.type === "call_limit") {
        alert(data.message);
        return;
    }

    if (
        data.type === "incoming_call" &&
        data.username &&
        data.username !== currentUser
    ) {
        document.getElementById("call-panel")
            .classList.remove("hidden");

        document.getElementById("call-status").innerText =
            `${data.username} is calling...`;

        return;
    }

    if (
        data.type === "call_accept" &&
        data.username !== currentUser
    ) {
        handleCallAccepted();
        return;
    }

    if (data.type === "image") {
        const messageClass =
            data.username === currentUser ? "my-message" : "their-message";

        const chatLog = document.querySelector("#chat-log");

        chatLog.insertAdjacentHTML("beforeend", `
            <div class="chat-message ${messageClass}">
                <img
                    src="${data.image_url.replace(
                        "/upload/",
                        "/upload/f_auto,q_auto,w_300,h_300,c_fill,g_auto/"
                    )}"
                    loading="lazy"
                    class="chat-image"
                    alt="Chat image"
                >
                <span>${new Date().toLocaleTimeString([], {
                    hour: "2-digit",
                    minute: "2-digit"
                })}</span>
            </div>
        `);

        const newImage =
            chatLog.querySelector(".chat-message:last-child img");

        if (newImage) {
            newImage.addEventListener("load", scrollToBottom);
        }

        scrollToBottom();
        return;
    }

    if (
        data.username === currentUser &&
        [
            "webrtc_offer",
            "webrtc_answer",
            "ice_candidate"
        ].includes(data.type)
    ) {
        return;
    }

    if (data.type === "webrtc_offer") {
        handleWebRTCOffer(data.offer);
        return;
    }

    if (data.type === "webrtc_answer") {
        handleWebRTCAnswer(data.answer);
        return;
    }

    if (data.type === "ice_candidate") {
        handleIceCandidate(data.candidate);
        return;
    }

    if (data.type !== "chat_message") {
        return;
    }

    const messageClass =
        data.username === currentUser ? "my-message" : "their-message";

    const chatLog = document.querySelector("#chat-log");

    chatLog.insertAdjacentHTML("beforeend", `
        <div class="chat-message ${messageClass}">
            <p>${data.message}</p>
            <span>${new Date().toLocaleTimeString([], {
                hour: "2-digit",
                minute: "2-digit"
            })}</span>
        </div>
    `);

    scrollToBottom();
};

document.querySelector("#chat-message-submit").onclick = function() {
    const messageInput = document.querySelector("#chat-message-input");
    const message = messageInput.value.trim();
    const imageInput = document.querySelector("#chat-image-input");
    const image = imageInput.files[0];

    if (image && image.size > 2 * 1024 * 1024) {
        alert("Image must be smaller than 2MB.");
        return;
    }

    if (message === "" && !image) {
        return;
    }

    if (window.chatSocket.readyState !== WebSocket.OPEN) {
        window.location.reload();
        return;
    }

    window.chatSocket.send(JSON.stringify({
        message: message,
        is_voice: false
    }));

    messageInput.value = "";
    messageInput.focus();
    scrollToBottom();
};

document.querySelector("#chat-message-input").addEventListener(
    "keyup",
    function(e) {
        if (e.key === "Enter") {
            document.querySelector("#chat-message-submit").click();
        }
    }
);

function scrollToBottom() {
    const chatLog = document.querySelector("#chat-log");

    if (!chatLog) {
        return;
    }

    function doScroll() {
        chatLog.scrollTop = chatLog.scrollHeight;
    }

    requestAnimationFrame(doScroll);
    setTimeout(doScroll, 50);
    setTimeout(doScroll, 150);
    setTimeout(doScroll, 400);
    setTimeout(doScroll, 800);
}

const messageInput = document.querySelector("#chat-message-input");

function fixIOSInputPosition() {
    setTimeout(function() {
        window.scrollTo(0, 0);
        scrollToBottom();
    }, 300);
}

if (messageInput) {
    messageInput.addEventListener("blur", fixIOSInputPosition);
}

window.addEventListener("load", function() {
    scrollToBottom();
});

window.addEventListener("pageshow", function() {

    if (messageInput) {
        messageInput.disabled = false;
    }
    
    scrollToBottom();
});
